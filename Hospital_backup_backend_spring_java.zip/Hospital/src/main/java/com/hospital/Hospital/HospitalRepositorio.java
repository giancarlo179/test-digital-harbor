package com.hospital.Hospital;

import java.util.List;

import org.springframework.data.repository.Repository;

public interface HospitalRepositorio extends Repository<Hospital, Integer> {
	List<Hospital>findAll();
	Hospital findById(int id);
	Hospital save(Hospital p);
	void delete(Hospital p);
}
