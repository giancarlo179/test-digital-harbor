package com.hospital.Hospital;

import java.util.List;

public interface NotasService {

	List<Notas>listar();
	Notas listarId(int id);
	Notas add(Notas p);
	Notas edit(Notas p);
	Notas delete(int id);
}
