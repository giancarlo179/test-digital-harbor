package com.hospital.Hospital;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class PacienteServiceImp implements PacienteService{
	
	@Autowired
	private PacienteRepositorio repositorio;

	@Override
	public List<Paciente> listar() {
		// TODO Auto-generated method stub
		return repositorio.findAll();
	}

	@Override
	public Paciente listarId(int id) {
		// TODO Auto-generated method stub
		return repositorio.findById(id);
	}

	@Override
	public Paciente add(Paciente p) {
		// TODO Auto-generated method stub
		return repositorio.save(p);
	}

	@Override
	public Paciente edit(Paciente p) {
		// TODO Auto-generated method stub
		return repositorio.save(p);
	}

	@Override
	public Paciente delete(int id) {
		// TODO Auto-generated method stub
		Paciente p=repositorio.findById(id);
		if(p!=null){
			repositorio.delete(p);
		}
		return p;
	}
}
