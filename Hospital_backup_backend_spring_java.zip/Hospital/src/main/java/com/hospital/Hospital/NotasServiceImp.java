package com.hospital.Hospital;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class NotasServiceImp implements NotasService{

	@Autowired
	private NotasRepositorio repositorio;
	
	@Override
	public List<Notas> listar() {
		// TODO Auto-generated method stub
		return repositorio.findAll();
	}

	@Override
	public Notas listarId(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Notas add(Notas p) {
		// TODO Auto-generated method stub
		return repositorio.save(p);
	}

	@Override
	public Notas edit(Notas p) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Notas delete(int id) {
		// TODO Auto-generated method stub
		return null;
	}

}
