package com.hospital.Hospital;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class HospitalServiceImp implements HospitalService{

	@Autowired
	private HospitalRepositorio repositorio;
	
	@Override
	public List<Hospital> listar() {
		// TODO Auto-generated method stub
		return repositorio.findAll();
	}

	@Override
	public Hospital listarId(int id) {
		// TODO Auto-generated method stub
		return repositorio.findById(id);
	}

	@Override
	public Hospital add(Hospital p) {
		// TODO Auto-generated method stub
		return repositorio.save(p);
	}

	@Override
	public Hospital edit(Hospital p) {
		// TODO Auto-generated method stub
		return repositorio.save(p);
	}

	@Override
	public Hospital delete(int id) {
		// TODO Auto-generated method stub
		Hospital p=repositorio.findById(id);
		if(p!=null){
			repositorio.delete(p);
		}
		return p;
	}

}
