package com.hospital.Hospital;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class DoctorServiceImp implements DoctorServive{

	@Autowired
	private DoctorRepositorio repositorio;
	
	@Override
	public List<Doctor> listar() {
		// TODO Auto-generated method stub
		return repositorio.findAll();
	}

	@Override
	public Doctor listarId(int id) {
		// TODO Auto-generated method stub
		return repositorio.findById(id);
	}

	@Override
	public Doctor add(Doctor p) {
		// TODO Auto-generated method stub
		return repositorio.save(p);
	}

	@Override
	public Doctor edit(Doctor p) {
		// TODO Auto-generated method stub
		return repositorio.save(p);
	}

	@Override
	public Doctor delete(int id) {
		// TODO Auto-generated method stub
		Doctor p=repositorio.findById(id);
		if(p!=null){
			repositorio.delete(p);
		}
		return p;
	}
	

}
