package com.hospital.Hospital;

import java.util.List;

import org.springframework.data.repository.Repository;

public interface EspecialidadRepositorio extends Repository<Especialidad, Integer> {
	List<Especialidad>findAll();
	Especialidad findById(int id);
	Especialidad save(Especialidad p);
	void delete(Especialidad p);
}
