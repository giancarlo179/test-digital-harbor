package com.hospital.Hospital;

import java.util.List;

import org.springframework.data.repository.Repository;

public interface NotasRepositorio extends Repository<Notas, Integer> {
	List<Notas>findAll();
	Notas findById(int id);
	Notas save(Notas p);
	void delete(Notas p);
}
