package com.hospital.Hospital;

import java.util.List;

public interface EspecialidadService {

	List<Especialidad>listar();
	Especialidad listarId(int id);
	Especialidad add(Especialidad p);
	Especialidad edit(Especialidad p);
	Especialidad delete(int id);
}
