package com.hospital.Hospital;

import java.util.List;
public interface DoctorServive {

	List<Doctor>listar();
	Doctor listarId(int id);
	Doctor add(Doctor p);
	Doctor edit(Doctor p);
	Doctor delete(int id);
}
