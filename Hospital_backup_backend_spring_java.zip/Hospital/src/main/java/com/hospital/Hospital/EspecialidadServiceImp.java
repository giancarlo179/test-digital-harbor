package com.hospital.Hospital;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class EspecialidadServiceImp implements EspecialidadService{

	@Autowired
	private EspecialidadRepositorio repositorio;
	
	@Override
	public List<Especialidad> listar() {
		// TODO Auto-generated method stub
		return repositorio.findAll();
	}

	@Override
	public Especialidad listarId(int id) {
		// TODO Auto-generated method stub
		return repositorio.findById(id);
	}

	@Override
	public Especialidad add(Especialidad p) {
		// TODO Auto-generated method stub
		return repositorio.save(p);
	}

	@Override
	public Especialidad edit(Especialidad p) {
		// TODO Auto-generated method stub
		return repositorio.save(p);
	}

	@Override
	public Especialidad delete(int id) {
		// TODO Auto-generated method stub
		Especialidad p=repositorio.findById(id);
		if(p!=null){
			repositorio.delete(p);
		}
		return p;
	}

}
