package com.hospital.Hospital;

import javax.persistence.*;

@Entity
@Table(name = "doctores")
public class Doctor {
	
	
	@Id
	@Column
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	@Column
	private String Nombre;
	@Column
	private String Apellidos;
	@Column
	private String FechaNacimiento;
	@Column
	private String Direccion;
	@Column
	private String FotoPerfil;
	@Column
	private String FechaCreacion;
	@Column
	private String Telefono;
	@Column
	private String Especialidad;
	
	public String getEspecialidad() {
		return Especialidad;
	}
	public void setEspecialidad(String especialidad) {
		Especialidad = especialidad;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getNombre() {
		return Nombre;
	}
	public void setNombre(String nombre) {
		Nombre = nombre;
	}
	public String getApellidos() {
		return Apellidos;
	}
	public void setApellidos(String apellidos) {
		Apellidos = apellidos;
	}
	public String getFechaNacimiento() {
		return FechaNacimiento;
	}
	public void setFechaNacimiento(String fechaNacimiento) {
		FechaNacimiento = fechaNacimiento;
	}
	public String getDireccion() {
		return Direccion;
	}
	public void setDireccion(String direccion) {
		Direccion = direccion;
	}
	public String getFotoPerfil() {
		return FotoPerfil;
	}
	public void setFotoPerfil(String fotoPerfil) {
		FotoPerfil = fotoPerfil;
	}
	public String getFechaCreacion() {
		return FechaCreacion;
	}
	public void setFechaCreacion(String fechaCreacion) {
		FechaCreacion = fechaCreacion;
	}
	public String getTelefono() {
		return Telefono;
	}
	public void setTelefono(String telefono) {
		Telefono = telefono;
	}
	
}
