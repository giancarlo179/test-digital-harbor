package com.hospital.Hospital;

import java.util.List;

public interface HospitalService {

	
	List<Hospital>listar();
	Hospital listarId(int id);
	Hospital add(Hospital p);
	Hospital edit(Hospital p);
	Hospital delete(int id);
}
